# Data Dictionary

## `synthetic_risk_register.csv`

| Column | Description |
|---|---|
| `risk_id` | Synthetic identifier for a risk-plan row |
| `risk_category` | Top-level risk grouping |
| `risk_description` | Plain-language synthetic description of the risk |
| `impact_level` | Impact score from 1 to 5 |
| `probability_level` | Probability score from 1 to 5 |
| `priority_level` | `impact_level * probability_level` |
| `mitigation_plan` | Plan assigned to reduce or monitor the risk |
| `planned_mitigation_impact` | Planned aggregate mitigation effect from actions |
| `owner` | Synthetic owner name/title |
| `status_summary` | Summary state for the plan |
| `risk_area` | Business area grouping |

## `synthetic_actions.csv`

| Column | Description |
|---|---|
| `action_id` | Synthetic action identifier |
| `risk_category` | Parent risk category |
| `mitigation_plan` | Parent mitigation plan |
| `action` | Action description |
| `mitigation_impact` | Per-action mitigation effect |
| `deadline` | Synthetic due date |
| `owner` | Synthetic owner |
| `status` | `Pending`, `In Progress`, `Complete`, or `Overdue` |
| `erm_bcm_management_type` | Synthetic ERM/BCM lifecycle grouping |
| `management_detail` | More specific control/process descriptor |
| `notes` | Demo note |

## `synthetic_aggregations.csv`

| Column | Description |
|---|---|
| `total_actions` | Total count of actions in the plan |
| `completed_actions` | Count complete |
| `in_progress_actions` | Count in progress |
| `pending_actions` | Count pending |
| `overdue_actions` | Count overdue |
| `mitigation_effect` | Sum of completed mitigation impact |
| `adjusted_score` | Weighted score after subtracting mitigation effect |