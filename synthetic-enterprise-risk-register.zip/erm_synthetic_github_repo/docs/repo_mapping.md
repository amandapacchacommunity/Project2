# Repo Mapping to Source Concept

This repository recreates the main ideas from the source ERM design in a public-safe way.

## Mapped concepts

### 1. Risk Register tab
Mapped to:
- `data/synthetic_risk_register.csv`

Comparable fields:
- Risk description
- Impact level
- Probability level
- Priority level
- Mitigation notes / plan
- Owner

### 2. Actions tab
Mapped to:
- `data/synthetic_actions.csv`

Comparable fields:
- Risk category
- Assigned mitigation plan
- Actions
- Mitigation impact
- Deadline
- Owner
- ERM/BCM management type
- Management detail

### 3. Reporting and aggregation
Mapped to:
- `data/synthetic_aggregations.csv`
- `src/build_reports.py`
- `app.py`

Comparable outputs:
- mitigation rollups
- status counts
- overdue action visibility
- adjusted / residual-style scoring
- chartable reporting dataset

## Public-safe changes

- All names, descriptions, dates, and assignments are synthetic.
- No confidential institutional details are preserved.
- The repo is simplified for GitHub and local execution.