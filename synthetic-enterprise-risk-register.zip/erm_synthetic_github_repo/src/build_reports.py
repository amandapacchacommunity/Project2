"""Build aggregated reporting datasets from synthetic ERM data."""
from __future__ import annotations

from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def adjusted_score(impact_level: float, probability_level: float, mitigation_effect: float) -> int:
    """Adjusted score inspired by the logic described in the source material."""
    return round(((impact_level ** 2 + probability_level ** 2) / 2) - mitigation_effect)


def build_aggregations(risk_df: pd.DataFrame, actions_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate action progress by risk category and mitigation plan."""
    grouped = (
        actions_df.groupby(["risk_category", "mitigation_plan"], as_index=False)
        .agg(
            total_actions=("action", "count"),
            completed_actions=("status", lambda s: int((s == "Complete").sum())),
            in_progress_actions=("status", lambda s: int((s == "In Progress").sum())),
            pending_actions=("status", lambda s: int((s == "Pending").sum())),
            overdue_actions=("status", lambda s: int((s == "Overdue").sum())),
            mitigation_effect=("mitigation_impact", lambda s: round((actions_df.loc[s.index, "status"].eq("Complete") * actions_df.loc[s.index, "mitigation_impact"]).sum(), 2)),
        )
    )

    merged = grouped.merge(
        risk_df[
            [
                "risk_category",
                "mitigation_plan",
                "impact_level",
                "probability_level",
                "priority_level",
                "owner",
                "status_summary",
            ]
        ],
        on=["risk_category", "mitigation_plan"],
        how="left",
    )

    merged["adjusted_score"] = merged.apply(
        lambda row: adjusted_score(
            row["impact_level"],
            row["probability_level"],
            row["mitigation_effect"],
        ),
        axis=1,
    )
    return merged.sort_values(["priority_level", "risk_category"], ascending=[False, True])


def main() -> None:
    risk_df = pd.read_csv(DATA_DIR / "synthetic_risk_register.csv")
    actions_df = pd.read_csv(DATA_DIR / "synthetic_actions.csv")
    agg_df = build_aggregations(risk_df, actions_df)
    agg_df.to_csv(DATA_DIR / "synthetic_aggregations.csv", index=False)
    print(f"Saved {len(agg_df)} aggregated rows to {DATA_DIR / 'synthetic_aggregations.csv'}")


if __name__ == "__main__":
    main()