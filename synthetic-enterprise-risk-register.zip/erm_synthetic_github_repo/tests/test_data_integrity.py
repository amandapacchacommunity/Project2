from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def test_files_exist() -> None:
    assert (DATA_DIR / "synthetic_risk_register.csv").exists()
    assert (DATA_DIR / "synthetic_actions.csv").exists()
    assert (DATA_DIR / "synthetic_aggregations.csv").exists()


def test_priority_is_product() -> None:
    df = pd.read_csv(DATA_DIR / "synthetic_risk_register.csv")
    assert ((df["impact_level"] * df["probability_level"]) == df["priority_level"]).all()


def test_action_impacts_are_non_negative() -> None:
    df = pd.read_csv(DATA_DIR / "synthetic_actions.csv")
    assert (df["mitigation_impact"] >= 0).all()


def test_expected_columns_present() -> None:
    df = pd.read_csv(DATA_DIR / "synthetic_actions.csv")
    expected = {"action_id", "risk_category", "mitigation_plan", "action", "mitigation_impact", "deadline", "owner", "status"}
    assert expected.issubset(df.columns)